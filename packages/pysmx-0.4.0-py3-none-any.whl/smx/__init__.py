from smx.compiler import compile_plugin
from smx.plugin import SourcePawnPlugin
from smx.version import VERSION
__version__ = VERSION
