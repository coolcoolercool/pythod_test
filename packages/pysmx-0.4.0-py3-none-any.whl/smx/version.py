VERSION = '0.4.0'
version_info = tuple(int(p) for p in VERSION.split('.'))
